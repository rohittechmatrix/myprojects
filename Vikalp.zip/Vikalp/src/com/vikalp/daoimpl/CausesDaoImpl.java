package com.vikalp.daoimpl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.vikalp.dao.CausesDao;
import com.vikalp.model.AddCauseForm;
import com.vikalp.model.Cause;
import com.vikalp.model.Support;
import com.vikalp.model.User;
import com.vikalp.util.SavePhotoUtil;

public class CausesDaoImpl implements CausesDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	final static Logger logger = Logger.getLogger(CausesDaoImpl.class);

	@Override
	public List<Cause> getCauses(String userrole, String username) {
		List<Cause> causes = null;
		try {

			String sql = "SELECT nc.cause_id,nc.type,nc.title,nc.details,nc.image,nc.amount,nc.ngo_username,nc.added_on,nc.is_completed FROM ngo_causes nc join user_login ul on (nc.ngo_username=ul.username) where nc.delete_flag=0 and ul.activeFlag=1 ";

			String addClause = "";
			if (userrole != null) {
				if (userrole.equals("ngo")) {
					addClause = " and ngo_username='" + username + "'";
					sql = sql + addClause;
				}
			}
			causes = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cause>(
					Cause.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return causes;
	}

	@Override
	public List<Cause> getAllCauses(String userrole, String username) {
		List<Cause> causes = null;
		try {

			String sql = "SELECT cause_id,type,title,details,image,amount,ngo_username,added_on,is_completed,delete_flag FROM ngo_causes where ngo_username='"
					+ username + "'";

			causes = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cause>(
					Cause.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return causes;
	}

	@Override
	public boolean deleteCause(int id, Object flag) {

		try {

			Date date = new Date(System.currentTimeMillis());
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String s = formatter.format(date);

			String sql = "update ngo_causes set delete_flag=1,is_completed="
					+ flag + ",deleted_on='" + s + "' where cause_id=" + id;

			int row = jdbcTemplate.update(sql);

			return (row == 1);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public Cause getCauseDetail(int causeId) {
		List<Cause> causes = null;
		try {

			String sql = "SELECT nc.cause_id,nc.type,nc.title,nc.details,nc.image,nc.amount,nc.ngo_username,nc.added_on,ul.address,ul.bank_name,ul.ifsc_code as iisfsc,ul.account_no as accountNumber FROM ngo_causes nc join user_login ul on (nc.ngo_username=ul.username) where nc.delete_flag=0 and nc.cause_id="
					+ causeId;

			causes = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cause>(
					Cause.class));
			if (causes.size() > 0)
				return causes.get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}
	
	@Override
	public Cause getCauseDetailComplete(int causeId) {
		List<Cause> causes = null;
		try {

			String sql = "SELECT nc.cause_id,nc.type,nc.title,nc.details,nc.image,nc.amount,nc.ngo_username,nc.added_on,ul.address,nc.deleted_on FROM ngo_causes nc join user_login ul on (nc.ngo_username=ul.username) where nc.delete_flag=1 and nc.is_completed=1 and nc.cause_id="
					+ causeId;

			causes = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cause>(
					Cause.class));
			if (causes.size() > 0)
				return causes.get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public boolean addCause(AddCauseForm addCauseForm, String user) {

		try {
			Calendar cal = Calendar.getInstance();
			addCauseForm.setUser(user);
			addCauseForm.setAdded(cal.getTime());

			String sql = "INSERT INTO ngo_causes (type,title,details,amount,ngo_username,added_on) VALUES "
					+ " (:type,:heading,:details,:amount,:user,:added)";

			SqlParameterSource fileParameters = new BeanPropertySqlParameterSource(
					addCauseForm);

			long causeId = insertAndGetId(sql, fileParameters,
					new String[] { "id" });

			String imagePath = "default_cause.jpg";
			if (!addCauseForm.getImages().isEmpty()) {
				imagePath = causeId + "_cause.jpg";
				SavePhotoUtil.savePhoto(imagePath, addCauseForm.getImages());
			}

			String updateSql = "update ngo_causes set image='" + imagePath
					+ "' where cause_id=" + causeId;

			int row = jdbcTemplate.update(updateSql);

			return true;

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	private long insertAndGetId(String sql, SqlParameterSource paramSource,
			String[] keyColumnNames) {
		long id = 0;

		KeyHolder keyHolder = new GeneratedKeyHolder();
		namedParameterJdbcTemplate.update(sql, paramSource, keyHolder,
				keyColumnNames);
		id = keyHolder.getKey().intValue();
		return id;
	}

	@Override
	public List<Cause> getCausesbyId(int userId) {
		List<Cause> causes = null;
		try {

			String sql = "SELECT cause_id,type,title,details,image,amount,ngo_username,added_on FROM ngo_causes nc join user_login ul on (nc.ngo_username=ul.username) where nc.delete_flag=0 and ul.id="
					+ userId;

			causes = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cause>(
					Cause.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return causes;

	}

	@Override
	public List<Support> getSupportedCausesbyId(int userId) {
		List<Support> supports = null;

		try {
			String sql = "SELECT nc.cause_id,nc.title,nc.ngo_username,ul.name,ul.number,cs.supported_on FROM causes_support cs join ngo_causes nc on (cs.cause_id = nc.cause_id) join user_login ul on (cs.donator_id = ul.id) where ul.id="+userId;

			supports = jdbcTemplate.query(sql,
					new BeanPropertyRowMapper<Support>(Support.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return supports;

	}

	@Override
	public boolean supportCause(int causeId, Integer userId, Object date,
			String pickaddress, String duration, String quantity) {
		try {

			String sql = "INSERT INTO causes_support (donator_id,cause_id,pickup_date,supported_on,pickup_address,duration,quantity) "
					+ "VALUES (?,?,?,?,?,?,?) ";

			int row = jdbcTemplate.update(sql, userId, causeId, date, Calendar
					.getInstance().getTime().toString(), pickaddress, duration,
					quantity);

			return (row == 1);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public String updateLikes(Object attribute, int causeId) {
		try {
			User usr = null;
			if (attribute != null) {
				usr = (User) attribute;
			}

			String sql = "INSERT INTO cause_likes (cause_id,liked_by) "
					+ "VALUES (?,?) ";

			int row = jdbcTemplate.update(sql, causeId, usr.getId());

			return "success";

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return "fail";
	}

	@Override
	public boolean isLikedAlready(int causeId, Integer id) {
		try {
			String sql = "select id from cause_likes where cause_id=" + causeId
					+ " and liked_by=" + id;

			Integer row = jdbcTemplate.queryForInt(sql);

			if (row != null)
				return true;

		} catch (Exception e) {
			// logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public List<Cause> getCausesByDeleteFlag(String userrole, String username) {
		List<Cause> causes = null;
		try {

			String sql = "SELECT cause_id,type,title,details,image,amount,ngo_username,added_on,deleted_on FROM ngo_causes where delete_flag=1 and is_completed=1 ";

			String addClause = "";
			if (userrole != null) {
				if (userrole.equals("ngo")) {
					addClause = " and ngo_username='" + username + "'";
					sql = sql + addClause;
				}
			}
			causes = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cause>(
					Cause.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return causes;
	}

	@Override
	public List<Cause> getCausesByDeleteWithdrawn(String userrole,
			String username) {
		List<Cause> causes = null;
		try {

			String sql = "SELECT cause_id,type,title,details,image,amount,ngo_username,added_on,deleted_on FROM ngo_causes where delete_flag=1 and is_completed=0 ";

			String addClause = "";
			if (userrole != null) {
				if (userrole.equals("ngo")) {
					addClause = " and ngo_username='" + username + "'";
					sql = sql + addClause;
				}
			}
			causes = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cause>(
					Cause.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return causes;
	}

	@Override
	public boolean setPriority(int causeId, int priority) {
		try {
			String updateSql = "update ngo_causes set priority =" + priority
					+ " where cause_id=" + causeId;

			int row = jdbcTemplate.update(updateSql);
			return true;

		} catch (Exception e) {

		}
		return false;
	}

	@Override
	public List<Cause> getSupportedCauses() {
		List<Cause> causes = null;
		try {

			String sql = "SELECT cause_id,type,title,details,image,amount,ngo_username,added_on FROM ngo_causes where is_completed=1 ";

			causes = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cause>(
					Cause.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return causes;
	}

	@Override
	public List<Support> getSupporters(int causeId) {
		List<Support> support = null;
		try {

			String sql = "SELECT nc.cause_id,ul.name,cs.supported_on FROM causes_support cs join ngo_causes nc on (cs.cause_id = nc.cause_id) join user_login ul on (cs.donator_id = ul.id) " +
					" where nc.cause_id="+causeId;

			support = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Support>(Support.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return support;
	}

	@Override
	public List<Support> getFulFilledSupportList() {
		List<Support> supports = null;

		try {
			String sql = "SELECT nc.cause_id,nc.title,nc.ngo_username,ul.name,ul.number,cs.supported_on,ul.address FROM causes_support cs join ngo_causes nc on (cs.cause_id = nc.cause_id) join user_login ul on (cs.donator_id = ul.id) where nc.is_completed=1 ";

			supports = jdbcTemplate.query(sql,
					new BeanPropertyRowMapper<Support>(Support.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return supports;
	}
}
