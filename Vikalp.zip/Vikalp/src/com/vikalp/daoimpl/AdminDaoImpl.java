package com.vikalp.daoimpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.vikalp.dao.AdminDao;
import com.vikalp.model.NGO;
import com.vikalp.model.Support;

public class AdminDaoImpl implements AdminDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	final static Logger logger = Logger.getLogger(AdminDaoImpl.class);

	@Override
	public List<NGO> listNGOs() {

		List<NGO> ngoList = null;

		try {
			String sql = "SELECT id,name,email,number,user_type,address,registration_no,nationality,account_no,bank_name,ifsc_code,fcra,section80g,contact_person FROM user_login where user_type='ngo' and activeFlag=0 ";

			ngoList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<NGO>(
					NGO.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return ngoList;
	}

	@Override
	public List<NGO> listActiveNGOs() {
		List<NGO> ngoList = null;

		try {
			String sql = "SELECT id,name,email,number,user_type,address,registration_no,nationality,account_no,bank_name,ifsc_code,fcra,section80g,contact_person FROM user_login where user_type='ngo' and activeFlag=1 ";

			ngoList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<NGO>(
					NGO.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return ngoList;
	}

	@Override
	public boolean activateNGO(int id, String action) {

		int result = 0;
		try {
			String query = "";
			if (action.equalsIgnoreCase("active")) {
				query = "update user_login set activeFlag=1 where id=" + id;
			} else {
				query = "update user_login set activeFlag=0 where id=" + id;
			}

			result = jdbcTemplate.update(query);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return ((result == 1) ? true : false);
	}

	@Override
	public List<NGO> listDonators() {
		List<NGO> ngoList = null;

		try {
			String sql = "SELECT id,name,email,number,user_type,address,username FROM user_login where user_type='donator' and activeFlag=1 ";

			ngoList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<NGO>(
					NGO.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return ngoList;
	}

	@Override
	public List<Support> getSupportList() {
		List<Support> supports = null;

		try {
			String sql = "SELECT nc.cause_id,nc.title,nc.ngo_username,ul.name,ul.number,cs.supported_on FROM causes_support cs join ngo_causes nc on (cs.cause_id = nc.cause_id) join user_login ul on (cs.donator_id = ul.id) ";

			supports = jdbcTemplate.query(sql,
					new BeanPropertyRowMapper<Support>(Support.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return supports;
	}

	@Override
	public boolean deActivateDonor(int userid) {
		int result = 0;
		try {
			String query = "";

			query = "update user_login set activeFlag=0 where id=" + userid;

			result = jdbcTemplate.update(query);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return ((result == 1) ? true : false);
	}

	@Override
	public List<Support> getSupportListByUser(int id) {
		List<Support> supports = null;

		try {
			String sql = "SELECT nc.cause_id,nc.title,nc.ngo_username,ul.name,ul.number,cs.supported_on,cs.quantity as amount,cs.pickup_address as address FROM causes_support cs join ngo_causes nc on (cs.cause_id = nc.cause_id) " +
					" join user_login ul on (cs.donator_id = ul.id) " +
					" join user_login ul2 on (nc.ngo_username = ul2.username) " +
					" where nc.delete_flag=0 and ul2.id="+id;
					

			supports = jdbcTemplate.query(sql,
					new BeanPropertyRowMapper<Support>(Support.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return supports;
	}

	
	@Override
	public boolean deActivateCause(int causeid) {
		int result = 0;
		try {
			String query = "";

			query = "update ngo_causes set activeFlag=2 where id=" + causeid;

			result = jdbcTemplate.update(query);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return ((result == 1) ? true : false);
	}

	@Override
	public String getUserMail(String ngoname) {
		String mail = null;

		try {
			String sql = "SELECT email from user_login where username = '"
					+ ngoname + "'";

			mail = jdbcTemplate.queryForObject(sql, String.class);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return mail;
	}

	@Override
	public List<NGO> listRawDonators() {
		List<NGO> ngoList = null;

		try {
			String sql = "SELECT id,name,email,number,user_type,address,username FROM user_login where user_type='donator' and activeFlag=0 ";

			ngoList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<NGO>(
					NGO.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return ngoList;
	}

	@Override
	public boolean activateDonor(int userid) {
		int result = 0;
		try {
			String query = "";
		
				query = "update user_login set activeFlag=1 where id=" + userid;
			

			result = jdbcTemplate.update(query);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return ((result == 1) ? true : false);
		
	}

	@Override
	public List<Support> getSupportListDonor(Integer id) {
		List<Support> supports = null;

		try {
			String sql = "SELECT nc.cause_id,nc.title,nc.ngo_username,ul.name,ul.number,cs.supported_on,cs.quantity as amount,cs.pickup_address as address FROM causes_support cs join ngo_causes nc on (cs.cause_id = nc.cause_id) " +
					" join user_login ul on (cs.donator_id = ul.id) " +
					" where ul.id="+id;
					

			supports = jdbcTemplate.query(sql,
					new BeanPropertyRowMapper<Support>(Support.class));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return supports;
	}
	
	

}
