package com.vikalp.daoimpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.vikalp.dao.LoginDao;
import com.vikalp.model.User;

public class LoginDaoImpl implements LoginDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	final static Logger logger = Logger.getLogger(LoginDaoImpl.class);

	@Override
	public User doLogin(String uname, String pass) {
		try {
			//where BINARY username='Admin'; if case sensitive check for username then
			String query = "select id,user_type,activeFlag,name,username,address,email,number from user_login where username='"
					+ uname + "'and password ='" + pass + "'";

			List<User> users = jdbcTemplate.query(query,
					new BeanPropertyRowMapper<User>(User.class));

			if (users.size() > 0) {
				return users.get(0);

			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return null;
	}

	@Override
	public String doLogout() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean signUp(Object[] params, int[] types) {

		try {

			String sql = "INSERT INTO user_login (name,email,number,user_type,address,username,password,"
					+ "nationality,registration_no,account_no,ifsc_code,bank_name,activeFlag,age,"
					+ "fcra,section80g,contact_person,registration_date,expiry_date) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

			int row = jdbcTemplate.update(sql, params, types);

			return (row == 1);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public User getPassword(String username) {

		try {
			String query = "select email,password from user_login where username='"
					+ username + "'";

			List<User> users = jdbcTemplate.query(query,
					new BeanPropertyRowMapper<User>(User.class));

			if (users.size() > 0)
				return users.get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return null;
	}

	@Override
	public void updatePassword(String usrname, String oldPW, String newPW) {
		try {
			String updateSql = "update user_login set password ='" + newPW
					+ "' where username='" + usrname + "' and password='"
					+ oldPW + "'";

			int row = jdbcTemplate.update(updateSql);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}
}
