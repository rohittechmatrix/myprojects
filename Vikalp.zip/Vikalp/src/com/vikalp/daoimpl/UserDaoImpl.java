package com.vikalp.daoimpl;

import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Types;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.vikalp.dao.UserDao;
import com.vikalp.model.DonorDetailForm;
import com.vikalp.model.NGODetail;
import com.vikalp.model.NGODetailForm;
import com.vikalp.model.User;
import com.vikalp.util.SavePhotoUtil;

public class UserDaoImpl implements UserDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	TransactionTemplate transactionTemplate;

	final static Logger logger = Logger.getLogger(UserDaoImpl.class);

	@Override
	public User userDetail(String username) {

		List<User> users = null;

		try {
			String query = "select id,name,email,username,user_type,number,nationality,address from user_login where username='"
					+ username + "'";

			users = jdbcTemplate.query(query, new BeanPropertyRowMapper<User>(
					User.class));
			if (users.size() > 0)
				return users.get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean saveUserDetail(final NGODetailForm ngoDetailForm) {
	
			return (Boolean) transactionTemplate.execute(new TransactionCallback() {
				public Boolean doInTransaction(TransactionStatus tStatus) {
					Boolean res = false;
					Object savepoint = null;
					try {
						savepoint = tStatus.createSavepoint();
						
						ngoDetailForm.setUserType("ngo");
						ngoDetailForm.setActiveFlag(0);

						String sql = "INSERT INTO user_login (name,email,number,user_type,address,username,password,"
								+ "nationality,registration_no,account_no,ifsc_code,bank_name,activeFlag,"
								+ "fcra,section80g,contact_person,registration_date,expiry_date) "
								+ "VALUES (:name,:emailsignup,:phonesignup,:userType,:addresssignup,:usernamesignup,:passwordsignup,"
								+ ":nationality,:regnumber,:acnumber,:ifscnumber,:bank,:activeFlag,:fcra,:section80g,:contact_person,:registration_date"
								+ ",:expiry_date) ";

						SqlParameterSource fileParameters = new BeanPropertySqlParameterSource(
								ngoDetailForm);

						long userId = insertAndGetId(sql, fileParameters,
								new String[] { "id" });

						String logoimage = userId + "_user.jpg";
						String ngoimage = userId + "_ngo.jpg";
						String certificateimage = userId + "_ngocertificate.jpg";

						SavePhotoUtil.savePhoto(logoimage, ngoDetailForm.getImages()[0]);
						SavePhotoUtil.savePhoto(ngoimage, ngoDetailForm.getImages()[1]);
						SavePhotoUtil.savePhoto(certificateimage,
								ngoDetailForm.getCertificate());

						String sql2 = "INSERT INTO ngo_details (ngo_id,ngo_username,description,logo_url,causes_supported,web_url,"
								+ "ngo_picture,certificate_url) VALUES (?,?,?,?,?,?,?,?) ";

						String options = "";
						for (String s : ngoDetailForm.getOppType()) {
							options = options + s + ",";
						}

						Object[] params = new Object[] { userId,
								ngoDetailForm.getUsernamesignup(),
								ngoDetailForm.getDescription(), logoimage,
								options.substring(0, options.length() - 1),
								ngoDetailForm.getNgoname(), ngoimage, certificateimage };

						int[] types = new int[] { Types.INTEGER, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR };

						int row = jdbcTemplate.update(sql2, params, types);

						String url = "http://ideasandaction.org:8079/mail/ngoack.php?to="
								+ ngoDetailForm.getEmailsignup();

						URL obj = new URL(url);
						HttpURLConnection con = (HttpURLConnection) obj.openConnection();
						con.setRequestMethod("GET");
						int responseCode = con.getResponseCode();
						System.out.println("\nSending 'GET' request to URL : " + url
								+ "response code " + responseCode);
						res = true;
						// checking flag value i.e. inserted or not
					} catch (Exception e) {
						tStatus.rollbackToSavepoint(savepoint);
						logger.error(e.getMessage());
						res = false;
					}
					return res;
				}
			});
	}

	@Override
	public NGODetail getNgo(Integer userId) {
		List<NGODetail> ngos = null;

		try {
			String query = "select nd.ngo_id,nd.ngo_username,nd.description,nd.logo_url,nd.causes_supported,nd.web_url,"
					+ "nd.ngo_picture,ul.name from ngo_details nd join user_login ul on (nd.ngo_id = ul.id)  where nd.ngo_id ="
					+ userId;

			ngos = jdbcTemplate.query(query,
					new BeanPropertyRowMapper<NGODetail>(NGODetail.class));
			if (ngos.size() > 0)
				return ngos.get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return null;
	}

	@Override
	public List<NGODetail> getNgos() {
		List<NGODetail> ngos = null;

		try {
			String query = "select nd.ngo_id,nd.ngo_username,nd.description,nd.logo_url,nd.causes_supported,nd.web_url,nd.ngo_picture from ngo_details nd join user_login ul on "
					+ " (nd.ngo_id = ul.id) where ul.activeFlag=1 and ul.user_type='ngo' ";

			ngos = jdbcTemplate.query(query,
					new BeanPropertyRowMapper<NGODetail>(NGODetail.class));

			return ngos;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return null;
	}

	@Override
	public void saveDonorDetail(DonorDetailForm donorDetailForm, User user) {
		String profileimage = user.getId() + "_user.jpg";
		if (user.getUserType().equals("ngo")) {
			profileimage = user.getId() + "_ngo.jpg";
		}

		if (!donorDetailForm.getImages().isEmpty()) {
			SavePhotoUtil.savePhoto(profileimage, donorDetailForm.getImages());
		} else {
			profileimage = "default_user.jpg";
		}

		try {

			String sql = "INSERT INTO ngo_details (ngo_id,ngo_username,logo_url"
					+ ") VALUES (?,?,?) ";

			Object[] params = new Object[] { user.getId(), user.getUsername(),
					profileimage };

			int[] types = new int[] { Types.INTEGER, Types.VARCHAR,
					Types.VARCHAR };

			int row = jdbcTemplate.update(sql, params, types);

			// return (row==1);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

	@Override
	public NGODetailForm getNGODetailForm(String uname) {
		List<NGODetailForm> users = null;
		try {
			String query = "select ngo_id,ngo_username,description,logo_url,causes_supported,web_url,ngo_picture,certificate_url from ngo_details where ngo_username='"
					+ uname + "'";

			users = jdbcTemplate.query(query,
					new BeanPropertyRowMapper<NGODetailForm>(
							NGODetailForm.class));
			if (users.size() > 0)
				return users.get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return null;
	}

	private long insertAndGetId(String sql, SqlParameterSource paramSource,
			String[] keyColumnNames) {
		long id = 0;
			KeyHolder keyHolder = new GeneratedKeyHolder();
			namedParameterJdbcTemplate.update(sql, paramSource, keyHolder,
					keyColumnNames);
			id = keyHolder.getKey().intValue();
		return id;
	}

	@Override
	public String ngoDescription(Integer id) {

		String Description = null;

		try {
			String query = "select description from ngo_details where ngo_id="+id;
			Description = jdbcTemplate.queryForObject(query,String.class);
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return Description;
	}

	@Override
	public boolean editNgoDescription(Integer id, String Description) {
	
		boolean res=false;
		try {
			String query = "UPDATE ngo_details SET description = '"+Description+"' where ngo_id="+id;
			int i = jdbcTemplate.update(query);
			if(i==1){
				res =true;
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return res;
	}

}
