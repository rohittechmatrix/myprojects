package com.vikalp.daoimpl;

import java.sql.Types;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.vikalp.dao.BlogsDao;
import com.vikalp.model.AddBlogForm;
import com.vikalp.model.AddCommentForm;
import com.vikalp.model.Blog;
import com.vikalp.model.Comment;
import com.vikalp.model.User;
import com.vikalp.util.SavePhotoUtil;

public class BlogsDaoImpl implements BlogsDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	final static Logger logger = Logger.getLogger(BlogsDaoImpl.class);

	@Override
	public List<Blog> getAllBlogs() {
		List<Blog> blogs = null;
		try {
			String sql = "Select ub.blog_id,ub.priority,ub.title,ub.created_by,ub.created_on,image_url,count(bc.comment_id) as commentCount from user_blogs ub left outer join blog_comments bc on (ub.blog_id = bc.blog_id) "
					+ " where ub.delete_flag=1 group by ub.blog_id order by ub.priority ";
			blogs = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Blog>(
					Blog.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return blogs;
	}

	@Override
	public List<Blog> getBlogs() {
		List<Blog> blogs = null;
		try {
			String sql = "Select ub.blog_id,ub.priority,ub.title,ub.created_by,ub.created_on,image_url,count(bc.comment_id) as commentCount from user_blogs ub left outer join blog_comments bc on (ub.blog_id = bc.blog_id) "
					+ " where ub.delete_flag=1 group by ub.blog_id order by ub.priority  limit 0,5";
			blogs = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Blog>(
					Blog.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return blogs;
	}

	@Override
	public Blog getBlogDetails(int blogId) {
		List<Blog> blogs = null;
		try {

			String sql = "Select ub.blog_id,ub.title,ub.details,ub.created_by,ub.created_on,count(bl.id) as likes,ub.image_url,ub.video_url as video "
					+ " from user_blogs ub left outer join blog_likes bl on (ub.blog_id=bl.blog_id) where ub.blog_id="
					+ blogId + " group by bl.blog_id ";

			blogs = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Blog>(
					Blog.class));
			if (blogs.size() > 0)
				return blogs.get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public List<Comment> getBlogComments(int blogId,Integer userId) {
		List<Comment> comments = null;
		try {
			String sql = "Select bc.comment_id,bc.comment_by,bc.comment,bc.commented_on,bc.blog_picurl as commentPic, " +
					" bc.blog_videourl as commentVideo, cr.reply_details,cr.reply_id,cr.replied_by,cr.replied_on, " +
					" ul1.logo_url as commenterId,ul2.logo_url as replierId,count(distinct cl.id) as commentLikes, " +
					" count(distinct rl.id) as replyLikes, cl2.id as commentFlag,rl2.id as replyFlag " +
					" from blog_comments bc left outer join ngo_details ul1 on (bc.comment_by=ul1.ngo_username) " +
					" left outer join comment_replies cr on (bc.comment_id = cr.comment_id ) " +
					" left outer join ngo_details ul2 on (cr.replied_by=ul2.ngo_username) " +
					" left outer join comment_likes cl on (bc.comment_id=cl.comment_id) " +
					" left outer join comment_likes cl2 on (bc.comment_id=cl2.comment_id and cl2.liked_by="+userId+") " +
					" left outer join reply_likes rl on (cr.reply_id=rl.reply_id) " +
					" left outer join reply_likes rl2 on (cr.reply_id=rl2.reply_id and rl2.liked_by="+userId+") " +
					" where bc.blog_id="+blogId+" group by bc.comment_id,cr.reply_id " +
					" order by bc.comment_id,cr.reply_id desc ";
			comments = jdbcTemplate.query(sql,
					new BeanPropertyRowMapper<Comment>(Comment.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return comments;
	}

	@Override
	public boolean addComment(AddCommentForm addCommentForm, int blogId) {
		try {
			Calendar cal = Calendar.getInstance();

			addCommentForm.setBlogId(blogId);
			addCommentForm.setCreatedOn(cal.getTime());
			String sql = "INSERT INTO blog_comments (blog_id,comment,comment_by,commented_on,blog_videourl) VALUES "
					+ "(:blogId ,:comment,:createdBy,:createdOn,:videourl)";
			SqlParameterSource fileParameters = new BeanPropertySqlParameterSource(
					addCommentForm);

			long commentid = insertAndGetId(sql, fileParameters,
					new String[] { "comment_id" });

			String imagePath = commentid + "_comment.jpg";
			if (!addCommentForm.getImages().isEmpty()) {
				SavePhotoUtil.savePhoto(imagePath, addCommentForm.getImages());
				String sql1 = "update blog_comments set blog_picurl='"
						+ imagePath + "' where comment_id=" + commentid;

				jdbcTemplate.update(sql1);
			}

			return true;
		} catch (Exception e) {
			logger.error("error in adding comment"+e);
		}
		return false;
	}

	@Override
	public String updateLikes(Object obj, int blogId) {
		try {
			User usr = null;
			if (obj != null) {
				usr = (User) obj;
			}

			String sql = "INSERT INTO blog_likes (blog_id,liked_by) "
					+ "VALUES (?,?) ";

			int row = jdbcTemplate.update(sql, blogId, usr.getId());

			return "success";

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return "fail";
	}

	@Override
	public boolean addBlog(AddBlogForm addBlogForm) {

		try {
			Calendar cal = Calendar.getInstance();

			addBlogForm.setCreatedOn(cal.getTime());

			String sql = "INSERT INTO user_blogs (title,details,created_by,created_on,video_url) VALUES (:blog,:blogText,:createdBy,:createdOn,:video)";

			SqlParameterSource fileParameters = new BeanPropertySqlParameterSource(
					addBlogForm);

			long blogId = insertAndGetId(sql, fileParameters,
					new String[] { "blog_id" });

			String imagePath = blogId + "_blog.jpg";

			if (!addBlogForm.getImages().isEmpty()) {
				SavePhotoUtil.savePhoto(imagePath, addBlogForm.getImages());
			} else {
				imagePath = "default_blog.jpg";
			}
			String updateSql = "update user_blogs set image_url ='" + imagePath
					+ "' where blog_id=" + blogId;

			int row = jdbcTemplate.update(updateSql);

			return true;

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;

	}

	private long insertAndGetId(String sql, SqlParameterSource paramSource,
			String[] keyColumnNames) {
		long id = 0;
		try {
			KeyHolder keyHolder = new GeneratedKeyHolder();
			namedParameterJdbcTemplate.update(sql, paramSource, keyHolder,
					keyColumnNames);
			id = keyHolder.getKey().intValue();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return id;
	}

	@Override
	public boolean addReply(int commentId, String replyText, String user) {
		try {
			Calendar cal = Calendar.getInstance();

			String sql = "INSERT INTO comment_replies (replied_by,reply_details,replied_on,comment_id) VALUES (?,?,?,?)";

			Object[] params = new Object[] { user, replyText, cal.getTime(),
					commentId };

			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
					Types.TIMESTAMP, Types.INTEGER };

			int row = jdbcTemplate.update(sql, params, types);

			return (row == 1);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public boolean isLikedAlready(int blogId, Integer id) {
		try {
			String sql = "select id from blog_likes where blog_id=" + blogId
					+ " and liked_by=" + id;

			Integer row = jdbcTemplate.queryForInt(sql);

			if (row != null)
				return true;

		} catch (Exception e) {
			// logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public String deActiveBlog(int blogId) {
		try {
			String updateSql = "update user_blogs set delete_flag =" + 2
					+ " where blog_id=" + blogId;

			int row = jdbcTemplate.update(updateSql);
			return "success";

		} catch (Exception e) {

		}
		return "fail";
	}

	@Override
	public boolean setPriority(int blogId, int priority) {
		try {
			String updateSql = "update user_blogs set priority =" + priority
					+ " where blog_id=" + blogId;

			int row = jdbcTemplate.update(updateSql);
			return true;

		} catch (Exception e) {

		}
		return false;
	}

	@Override
	public List<Blog> getAllBlogsByUser(String uname) {
		List<Blog> blogs = null;
		try {
			String sql = "Select ub.blog_id,ub.priority,ub.title,ub.created_by,ub.created_on,image_url,count(bc.comment_id) as commentCount from user_blogs ub left outer join blog_comments bc on (ub.blog_id = bc.blog_id) "
					+ " where ub.delete_flag=1 and ub.created_by ='"
					+ uname
					+ "' group by ub.blog_id order by ub.priority ";
			blogs = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Blog>(
					Blog.class));

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return blogs;
	}

	@Override
	public String updateCommentLikes(Object obj, int commentId) {
		try {
			User usr = null;
			if (obj != null) {
				usr = (User) obj;
			}

			String sql = "INSERT INTO comment_likes (comment_id,liked_by) "
					+ "VALUES (?,?) ";

			int row = jdbcTemplate.update(sql, commentId, usr.getId());

			return "success";

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return "success";
	}

	@Override
	public String updateReplyLikes(Object obj, int replyId) {
		try {
			User usr = null;
			if (obj != null) {
				usr = (User) obj;
			}

			String sql = "INSERT INTO reply_likes (reply_id,liked_by) "
					+ "VALUES (?,?) ";

			int row = jdbcTemplate.update(sql, replyId, usr.getId());

			return "success";

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return "success";
	}

}
