package com.vikalp.util;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.web.multipart.MultipartFile;

public class SavePhotoUtil {

	// public static final String UPLOAD_IMAGE_WEB_FILESYSTEM_PATH ="C:/Users/aggarwalr/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/webapps/vikalpimages/";
	//public static final String UPLOAD_IMAGE_WEB_FILESYSTEM_PATH = "C:/AAworkspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/webapps/vikalpimages/";
	 public static final String UPLOAD_IMAGE_WEB_FILESYSTEM_PATH = System.getProperty("catalina.base")+"/webapps/vikalpimages/";

	final static Logger logger = Logger.getLogger(SavePhotoUtil.class);

	public static boolean savePhoto(String imageWithPath, MultipartFile file) {

		verifyAndCreatePath(UPLOAD_IMAGE_WEB_FILESYSTEM_PATH);
		String path = UPLOAD_IMAGE_WEB_FILESYSTEM_PATH + imageWithPath;

		File f = new File(path);

		try {

			if (file != null) {
				file.transferTo(f);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	private static void verifyAndCreatePath(String path) {
		File f = new File(path);
		if (!f.exists()) {
			f.mkdirs();
		}
	}
}
