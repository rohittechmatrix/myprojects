package com.vikalp.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.vikalp.dao.AdminDao;
import com.vikalp.dao.BlogsDao;
import com.vikalp.dao.CausesDao;
import com.vikalp.dao.UserDao;
import com.vikalp.model.DonorDetailForm;
import com.vikalp.model.NGODetail;
import com.vikalp.model.User;

@Controller
public class UserController {

	@Autowired
	private UserDao userDao;

	@Autowired
	@Qualifier("causesDao")
	private CausesDao causesDao;

	@Autowired
	@Qualifier("blogsDao")
	private BlogsDao blogsDao;

	@Autowired
	@Qualifier("adminDao")
	private AdminDao adminDao;

	final static Logger logger = Logger.getLogger(StaticPagesController.class);

	@RequestMapping(value = "update.htm", method = RequestMethod.GET)
	public ModelAndView searchAndRender(Model model,
			HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("donorDetailForm") DonorDetailForm donorDetailForm) {

		String msg = "success";
		try{
		String uname = request.getParameter("user");
		User user = userDao.userDetail(uname);
		model.addAttribute("user", user);
		model.addAttribute("blogs", blogsDao.getAllBlogsByUser(uname));
		model.addAttribute("supportList",adminDao.getSupportListByUser(user.getId()));
		model.addAttribute("supporteddonorList",adminDao.getSupportListDonor(user.getId()));
		model.addAttribute("causes", causesDao.getAllCauses("ngo", uname));
		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return new ModelAndView("update");
	}

	@RequestMapping(value = "donordetails.htm", method = RequestMethod.GET)
	public ModelAndView getUserDetails(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("donorDetailForm") DonorDetailForm donorDetailForm) {
		String msg = "success";
		try{
		String uname = request.getParameter("user");
		User user = userDao.userDetail(uname);
		model.addAttribute("user", user);
		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return new ModelAndView("donordetails");
	}
	
	@RequestMapping(value = "editDescription.htm", method = RequestMethod.GET)
	public ModelAndView getNgoDescription(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		
		try{
		User user = (User) request.getSession().getAttribute("user");
		String description = userDao.ngoDescription(user.getId());
		model.addAttribute("description", description);
		}catch (Exception e) {
			
		}
	
		return new ModelAndView("editDescription");
	}
	
	@RequestMapping(value = "editNgoDescription.htm", method = RequestMethod.POST)
	public String editNgoDescription(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		
		try{
		User user = (User) request.getSession().getAttribute("user");
		String Description = request.getParameter("description");
		boolean isSuccess= userDao.editNgoDescription(user.getId(),Description);
		if(isSuccess){
			model.addAttribute("msg", "Description Updated Successfully");
		}else{
			model.addAttribute("msg", "Some Error Occured. Please try again");	
		}
		}catch (Exception e) {
			
		}
	   
		return "redirect:editDescription.htm" ;
	}
	

	@RequestMapping(value = "update.htm", method = RequestMethod.POST)
	public String addDonordetails(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("donorDetailForm") DonorDetailForm donorDetailForm) {
		String msg = "success";
		String uname = null;
		try{
		uname = request.getParameter("user");
		User user = userDao.userDetail(uname);
		userDao.saveDonorDetail(donorDetailForm, user);
		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return "redirect:/update.htm?user=" + uname;
	}

	@RequestMapping(value = "getNgo.htm")
	public ModelAndView getNgo(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		String msg = "success";
		try{
		NGODetail ngoDetail = userDao.getNgo(Integer.parseInt(request
				.getParameter("userId").toString()));
		model.addAttribute("ngoDetail", ngoDetail);
		model.addAttribute(
				"causes",
				causesDao.getCausesbyId(Integer.parseInt(request.getParameter(
						"userId").toString())));
		model.addAttribute(
				"supported",
				causesDao.getSupportedCausesbyId(Integer.parseInt(request.getParameter("userId").toString())));
		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return new ModelAndView("NgoDetail");
	}
}
