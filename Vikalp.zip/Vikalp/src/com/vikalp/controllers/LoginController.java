/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vikalp.controllers;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Types;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.vikalp.dao.LoginDao;
import com.vikalp.dao.UserDao;
import com.vikalp.model.NGODetailForm;
import com.vikalp.model.User;

@Controller
public class LoginController {

	@Autowired
	@Qualifier("loginDao")
	private LoginDao loginDao;

	@Autowired
	private UserDao userDao;

	final static Logger logger = Logger.getLogger(LoginController.class);

	@RequestMapping(value = "login.htm")
	public String login(Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) {
		String msg = "";
		String view = "home.htm";
		try{
		String uname = null;
		String pass = null;
		
		uname = request.getParameter("username").trim();
		pass = request.getParameter("password");
		User user = loginDao.doLogin(uname, pass);
		
		if (user == null) {
			msg = "Invalid Username or Password!!!";
		} else {
			request.getSession(true);

			if (user.getUserType().equalsIgnoreCase("admin")) {
				session.setAttribute("uname", uname);
				session.setAttribute("user", user);
				session.setAttribute("role", "admin");
				view = "admin.htm";
			} else {
				if (user.getActiveFlag() == 1) {
					session.setAttribute("uname", uname);
					session.setAttribute("user", user);

					if (user.getUserType().equalsIgnoreCase("ngo")) {
						session.setAttribute("role", "ngo");
					} else {
						session.setAttribute("role", "donator");
						
					}
					view = "home.htm";
				} else {
					view = "CommonError.htm";
				}
			}
		}
		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return "redirect:/" + view;

	}

	@RequestMapping(value = "logout.htm")
	public String logout(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		request.getSession().invalidate();
		return "redirect:/home.htm";
	}
    
	@RequestMapping(value = "CommonError.htm")
	public ModelAndView commonError(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		return new ModelAndView("CommonError");
	}
	
	@RequestMapping(value = "signup.htm", method = RequestMethod.GET)
	public ModelAndView signup(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		return new ModelAndView("signup");
	}

	@RequestMapping(value = "signupngo.htm", method = RequestMethod.GET)
	public ModelAndView getUserDetails(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("ngoDetailForm") NGODetailForm ngoDetailForm) {
		return new ModelAndView("ngoRegister");
	}

	@RequestMapping(value = "signupngo.htm", method = RequestMethod.POST)
	public String addUserdetails(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("ngoDetailForm") NGODetailForm ngoDetailForm) {

		boolean isSuccess = userDao.saveUserDetail(ngoDetailForm);
		if(isSuccess){
			
			model.addAttribute("msg", "Registration Successful.");	
		}else{
			model.addAttribute("msg", "Username already exist. Please try with different Username");	
		}
		return "redirect:/home.htm";
	}

	@RequestMapping(value = "signUp.htm", method = RequestMethod.POST)
	public String SignUp(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		String msg = "Registration Successfull";
		String viewRedirect = "home.htm";
		try{
		String usermail = "";
		usermail = request.getParameter("emailsignup");
        
		int type = Integer
				.parseInt(request.getParameter("usertype").toString());
		String[] typeArr = new String[] { "donator", "child", "ngo" };
		Object[] params;
		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };

		params = new Object[] { request.getParameter("name"), usermail,
				request.getParameter("phonesignup"), typeArr[type],
				request.getParameter("addresssignup"),
				request.getParameter("usernamesignup"),
				request.getParameter("passwordsignup"),
				request.getParameter("nationality"), null, null, null, null, 1,
				request.getParameter("age"), null, null, null, null, null };

		boolean isSuccessfull = loginDao.signUp(params, types);
		if (isSuccessfull) {
			String url = "";

			url = "http://ideasandaction.org:8079/mail/welcome.php?to="
					+ usermail;

			try {
				URL obj = new URL(url);
				HttpURLConnection con = (HttpURLConnection) obj
						.openConnection();
				con.setRequestMethod("GET");
				int responseCode = con.getResponseCode();
				System.out.println("\nSending 'GET' request to URL : " + url
						+ "response code " + responseCode);
			} catch (Exception e) {
				System.out.println("exception in sending email on signup"
						+ e.getMessage());
				logger.error(e.getMessage());
			}
		} else {
			msg="Please try again. Username already exist";
			viewRedirect = "signup.htm";
		}
		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return "redirect:/"+viewRedirect;

	}

	@RequestMapping(value = "forgot.htm", method = RequestMethod.POST)
	public String forgot(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		String msg = "success";
		try{
		String username = "";
		username = request.getParameter("email");

		User user = loginDao.getPassword(username);
		if (user == null) {
			msg="Invalid Username";
		} else {
			String url = "";

			url = "http://ideasandaction.org:8079/mail/forgot.php?to="
					+ user.getEmail() + "&password=" + user.getPassword();
			try {
				URL obj = new URL(url);
				HttpURLConnection con = (HttpURLConnection) obj
						.openConnection();
				con.setRequestMethod("GET");
				int responseCode = con.getResponseCode();
				System.out.println("\nSending 'GET' request to URL : " + url
						+ "response code " + responseCode);
			} catch (Exception e) {
				System.out.println("exception in sending email on signup"
						+ e.getMessage());
				logger.error(e.getMessage());
			}
		}
		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return "redirect:/home.htm";
	}

	@RequestMapping(value = "updatepassword.htm", method = RequestMethod.POST)
	public String updatepassword(Model model, HttpServletRequest request,
			HttpSession session, HttpServletResponse response) {

		String usrname ="";
		String msg = "success";
		try{
		String oldPW = request.getParameter("currentpsw");
		String newPW = request.getParameter("newpassword");
		usrname = session.getAttribute("uname").toString();
		loginDao.updatePassword(usrname, oldPW, newPW);
		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return "redirect:/update.htm?user=" + usrname;
	}

}
