package com.vikalp.controllers;

import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.vikalp.dao.AdminDao;
import com.vikalp.dao.BlogsDao;
import com.vikalp.dao.CausesDao;

@Controller
public class AdminController {

	@Autowired
	@Qualifier("adminDao")
	private AdminDao adminDao;

	@Autowired
	@Qualifier("blogsDao")
	private BlogsDao blogsDao;

	@Autowired
	@Qualifier("causesDao")
	private CausesDao causesDao;

	final static Logger logger = Logger.getLogger(AdminController.class);

	@RequestMapping(value = "ngoList.htm")
	public ModelAndView ngosrp(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		model.addAttribute("ngoList", adminDao.listNGOs());
		return new ModelAndView("NgoSrp");
	}

	@RequestMapping(value = "donatorList.htm")
	public ModelAndView getDonatorsList(Model model,
			HttpServletRequest request, HttpServletResponse response) {
		model.addAttribute("donatorList", adminDao.listDonators());
		return new ModelAndView("DonatorSrp");
	}
	
	@RequestMapping(value = "rawdonors.htm")
	public ModelAndView rawdonors(Model model,
			HttpServletRequest request, HttpServletResponse response) {
		model.addAttribute("donatorList", adminDao.listRawDonators());
		return new ModelAndView("ActiveDonator");
	}
	
	@RequestMapping(value = "blogList.htm")
	public ModelAndView getBlogs(Model model, HttpServletRequest request,
			HttpServletResponse response) {

		model.addAttribute("blogs", blogsDao.getAllBlogs());
		return new ModelAndView("blogSrp");
	}

	@RequestMapping(value = "activecauseList.htm")
	public ModelAndView searchcauses(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		String msg = "success";
		try {
			Object userN = request.getSession().getAttribute("uname");
			Object userR = request.getSession().getAttribute("role");

			String user = (userN == null) ? null : userN.toString();
			String userrole = (userR == null) ? null : userR.toString();

			model.addAttribute("causes", causesDao.getCauses(userrole, user));
		}catch (Exception e) {
			msg="fail to fetch detail";
			logger.error(e.getMessage());
		}
		model.addAttribute("msg", msg);
		return new ModelAndView("causeSrp");
	}

	@RequestMapping(value = "fulfilledCauseList.htm")
	public ModelAndView searchcausesByDelete(Model model,
			HttpServletRequest request, HttpServletResponse response) {
		String msg = "success";
		try {
			Object userN = request.getSession().getAttribute("uname");
			Object userR = request.getSession().getAttribute("role");

			String user = (userN == null) ? null : userN.toString();
			String userrole = (userR == null) ? null : userR.toString();

			model.addAttribute("causes",
					causesDao.getCausesByDeleteFlag(userrole, user));

		}catch (Exception e) {
			msg="fail to fetch detail";
			logger.error(e.getMessage());
		}
		model.addAttribute("msg", msg);

		return new ModelAndView("fulfilledCauseList");
	}

	@RequestMapping(value = "awithdrawnCauseList.htm")
	public ModelAndView searchcausesByWithdrawn(Model model,
			HttpServletRequest request, HttpServletResponse response) {
		String msg = "success";
		try {
			Object userN = request.getSession().getAttribute("uname");
			Object userR = request.getSession().getAttribute("role");

			String user = (userN == null) ? null : userN.toString();
			String userrole = (userR == null) ? null : userR.toString();

			model.addAttribute("causes",
					causesDao.getCausesByDeleteWithdrawn(userrole, user));

		}catch (Exception e) {
			logger.error(e.getMessage());
		}
		return new ModelAndView("withdrawCause");
	}

	@RequestMapping(value = "Activate.htm", method = RequestMethod.GET)
	public @ResponseBody
	String activateNGO(@RequestParam int userid, @RequestParam String mail)
			throws Exception {
		String result = "fail";
		try {
			boolean res = adminDao.activateNGO(userid, "active");
			if (res) {
				result = "success";

				String url = "";

				url = "http://ideasandaction.org:8079/mail/ngoactivation.php?to="
						+ mail;
				try {
					URL obj = new URL(url);
					HttpURLConnection con = (HttpURLConnection) obj
							.openConnection();
					con.setRequestMethod("GET");
					int responseCode = con.getResponseCode();
					System.out.println("\nSending 'GET' request to URL : "
							+ url + "response code " + responseCode);
				} catch (Exception e) {
					System.out.println("exception in sending email on signup"
							+ e.getMessage());
				}
			}
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "Deactivate.htm", method = RequestMethod.GET)
	public @ResponseBody
	String DeactivateNGO(@RequestParam int userid, @RequestParam String mail)
			throws Exception {
		String result = "fail";
		try {
			boolean res = adminDao.activateNGO(userid, "deactive");
			if (res) {
				result = "success";

				String url = "";

				url = "http://ideasandaction.org:8079/mail/ngoactivation.php?to="
						+ mail;
				try {
					URL obj = new URL(url);
					HttpURLConnection con = (HttpURLConnection) obj
							.openConnection();
					con.setRequestMethod("GET");
					int responseCode = con.getResponseCode();
					System.out.println("\nSending 'GET' request to URL : "
							+ url + "response code " + responseCode);
				} catch (Exception e) {
					System.out.println("exception in sending email on signup"
							+ e.getMessage());
				}
			}
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "DeactivateCause.htm", method = RequestMethod.GET)
	public @ResponseBody
	String DeactivateCause(@RequestParam int causeid,
			@RequestParam String ngoname) throws Exception {
		String result = "fail";
		try {
			boolean res = adminDao.deActivateCause(causeid);
			String mail = adminDao.getUserMail(ngoname);
			if (res) {
				result = "success";

				String url = "";

				url = "http://ideasandaction.org:8079/mail/ngoactivation.php?to="
						+ mail;
				try {
					URL obj = new URL(url);
					HttpURLConnection con = (HttpURLConnection) obj
							.openConnection();
					con.setRequestMethod("GET");
					int responseCode = con.getResponseCode();
					System.out.println("\nSending 'GET' request to URL : "
							+ url + "response code " + responseCode);
				} catch (Exception e) {
					System.out.println("exception in sending email on signup"
							+ e.getMessage());
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "deActivateDonor.htm", method = RequestMethod.GET)
	public @ResponseBody
	String deActivateDonor(@RequestParam int userid, @RequestParam String mail)
			throws Exception {
		String result = "fail";
		try {
			boolean res = adminDao.deActivateDonor(userid);
			if (res) {
				result = "success";

				String url = "";

				url = "http://ideasandaction.org:8079/mail/ngoactivation.php?to="
						+ mail;
				try {
					URL obj = new URL(url);
					HttpURLConnection con = (HttpURLConnection) obj
							.openConnection();
					con.setRequestMethod("GET");
					int responseCode = con.getResponseCode();
					System.out.println("\nSending 'GET' request to URL : "
							+ url + "response code " + responseCode);
				} catch (Exception e) {
					System.out.println("exception in sending email on signup"
							+ e.getMessage());
				}
			}
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "setPriorityBlog.htm", method = RequestMethod.GET)
	public @ResponseBody
	String setPriorityBlog(@RequestParam int blogId, @RequestParam int priority)
			throws Exception {
		String result = "fail";
		try {
			boolean res = blogsDao.setPriority(blogId, priority);
			if (res) {
				result = "success";
			}
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "setPriorityCause.htm", method = RequestMethod.GET)
	public @ResponseBody
	String setPriorityCause(@RequestParam int causeId,
			@RequestParam int priority) throws Exception {
		String result = "fail";
		try {
			boolean res = causesDao.setPriority(causeId, priority);
			if (res) {
				result = "success";
			}
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "supportList.htm")
	public ModelAndView supportList(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		model.addAttribute("supportList", adminDao.getSupportList());
		return new ModelAndView("SupportSrp");
	}

	@RequestMapping(value = "activeNgoList.htm")
	public ModelAndView activeNgoList(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		model.addAttribute("ngoList", adminDao.listActiveNGOs());
		return new ModelAndView("ActiveNgoSrp");
	}

	@RequestMapping(value = "activateDonor.htm", method = RequestMethod.GET)
	public @ResponseBody
	String activateDonor(@RequestParam int userid, @RequestParam String mail)
			throws Exception {
		String result = "fail";
		try {
			boolean res = adminDao.activateDonor(userid);
			if (res) {
				result = "success";

				String url = "";

				url = "http://ideasandaction.org:8079/mail/ngoactivation.php?to="
						+ mail;
				try {
					URL obj = new URL(url);
					HttpURLConnection con = (HttpURLConnection) obj
							.openConnection();
					con.setRequestMethod("GET");
					int responseCode = con.getResponseCode();
					System.out.println("\nSending 'GET' request to URL : "
							+ url + "response code " + responseCode);
				} catch (Exception e) {
					System.out.println("exception in sending email on signup"
							+ e.getMessage());
				}
			}
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

}
