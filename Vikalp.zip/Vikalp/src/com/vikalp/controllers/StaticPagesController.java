package com.vikalp.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StaticPagesController {

	final static Logger logger = Logger.getLogger(StaticPagesController.class);

	@RequestMapping(value = "about.htm")
	public ModelAndView about(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		return new ModelAndView("about");
	}

	@RequestMapping(value = "contact.htm")
	public ModelAndView contact(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		return new ModelAndView("contact");
	}

	@RequestMapping(value = "admin.htm")
	public ModelAndView gotoAdmin(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		return new ModelAndView("Admin");
	}

}
