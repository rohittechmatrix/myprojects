package com.vikalp.controllers;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.vikalp.dao.AdminDao;
import com.vikalp.dao.CausesDao;
import com.vikalp.dao.UserDao;
import com.vikalp.model.AddCauseForm;
import com.vikalp.model.Cause;
import com.vikalp.model.Support;
import com.vikalp.model.User;

@Controller
public class CausesController {

	@Autowired
	private UserDao userDao;
	
	@Autowired
	@Qualifier("causesDao")
	private CausesDao causesDao;

	@Autowired
	@Qualifier("adminDao")
	private AdminDao adminDao;

	final static Logger logger = Logger.getLogger(CausesController.class);

	@RequestMapping(value = "searchcause.htm")
	public ModelAndView searchcauses(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		String msg = "success";
		try {
			Object userN = request.getSession().getAttribute("uname");
			Object userR = request.getSession().getAttribute("role");

			String user = (userN == null) ? null : userN.toString();
			String userrole = (userR == null) ? null : userR.toString();

			model.addAttribute("causes", causesDao.getCauses(userrole, user));

		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return new ModelAndView("searchcause");
	}

	@RequestMapping(value = "supportedcauses.htm")
	public ModelAndView supportedcauses(Model model,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			//model.addAttribute("causes", causesDao.getSupportedCauses());
			model.addAttribute("supportList", causesDao.getFulFilledSupportList());
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return new ModelAndView("SupportedCauses");
	}

	@RequestMapping(value = "addcause.htm", method = RequestMethod.GET)
	public ModelAndView getCruiseLines(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("addCauseForm") AddCauseForm addCauseForm) {
		return new ModelAndView("addcause");
	}

	@RequestMapping(value = "addcause.htm", method = RequestMethod.POST)
	public String addCause(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("addCauseForm") AddCauseForm addCauseForm) {

		// String heading = request.getParameter("heading").toString();
		// String type = request.getParameter("type").toString();
		// String amount = request.getParameter("amount").toString();
		// String details = request.getParameter("details").toString();
		// String image = request.getParameter("image").toString();

		String user = request.getSession().getAttribute("uname").toString();

		causesDao.addCause(addCauseForm, user);
		return "redirect:/searchcause.htm";
	}

	@RequestMapping(value = "deletecauses.htm")
	public String deletecauses(Model model, HttpServletRequest request,
			HttpServletResponse response) {

		Object isCompleted = request.getParameter("isCompleted");
		causesDao.deleteCause(Integer.parseInt(request.getParameter("causeId").toString()), isCompleted);
		return "redirect:/searchcause.htm";
	}

	@RequestMapping(value = "confirmSupport.htm")
	public ModelAndView confirmSupport(Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) {
		String msg = "success";
		try{
		Integer causeId = Integer.parseInt(request.getParameter("causeId")
				.toString());
		User user = (User) request.getSession().getAttribute("user");
		Integer donatorId = user.getId();
		String phone = user.getNumber();

		Object pick = request.getParameter("pickupDate");
		String pickaddress = request.getParameter("contactaddress");

		String duration = request.getParameter("duration");
		String quantity = request.getParameter("quantity");

		boolean isSuccess = causesDao.supportCause(causeId, donatorId, pick,
				pickaddress, duration, quantity);
		if (isSuccess) {
			Cause cause = causesDao.getCauseDetail(causeId);
			model.addAttribute("cause", cause);
			// User user = userDao.userDetail(uname);
			// model.addAttribute("user",user);
			model.addAttribute("pickup", pick);
			model.addAttribute("pickadd", pickaddress);

			String ngomail = adminDao.getUserMail(cause.getNgoUsername());

			String url1 = "http://ideasandaction.org:8079/mail/contact_me.php?to="
					+ ngomail
					+ "&phone="
					+ phone
					+ "&pickaddress="
					+ pickaddress;
			
				URL obj = new URL(url1);
				HttpURLConnection con = (HttpURLConnection) obj
						.openConnection();
				con.setRequestMethod("GET");
				int responseCode = con.getResponseCode();
				System.out.println("\nSending 'GET' request to URL : " + url1
						+ "response code " + responseCode);
			} 

		

		String url = "";
		url = "http://ideasandaction.org:8079/mail/contact_me.php?to="
				+ user.getEmail();
		
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			int responseCode = con.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url
					+ "response code " + responseCode);
		} catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);

		return new ModelAndView("SupportCause");
	}

	@RequestMapping(value = "causeDetail.htm")
	public ModelAndView causeDetail(Model model, HttpServletRequest request,
			HttpSession session, HttpServletResponse response) {
		String msg = "success";
		try{
		int causeId = Integer.parseInt(request.getParameter("id").toString());
		boolean isLiked = false;

		if (session.getAttribute("uname") != null) {
			isLiked = causesDao.isLikedAlready(causeId,
					userDao.userDetail(session.getAttribute("uname").toString()).getId());
		}

		Cause cause = causesDao.getCauseDetail(causeId);
		model.addAttribute("cause", cause);
		model.addAttribute("isLiked", isLiked);
	}catch (Exception e) {
		msg="fail to fetch detail";
	}
	model.addAttribute("msg", msg);
		return new ModelAndView("causeDetail1");
	}
	
	@RequestMapping(value = "completeCause.htm")
	public ModelAndView causeDetailCompleted(Model model, HttpServletRequest request,
			HttpSession session, HttpServletResponse response) {
		try{
		
		Cause cause = causesDao.getCauseDetailComplete(Integer.parseInt(request.getParameter("id").toString()));
		List<Support> supporterList = causesDao.getSupporters(Integer.parseInt(request.getParameter("id").toString()));
		model.addAttribute("cause", cause);
		model.addAttribute("supporterList", supporterList);
	}catch (Exception e) {
		logger.error(e.getMessage());
	}
	
		return new ModelAndView("fulfilledCause");
	}
	

	@RequestMapping(value = "updateCauselikes.htm", method = RequestMethod.GET)
	public @ResponseBody
	String updatelikes(HttpSession session, @RequestParam int causeId)
			throws Exception {
		String result = null;
		try {
			result = causesDao.updateLikes(userDao.userDetail(session.getAttribute("uname").toString()),
					causeId);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

}
