package com.vikalp.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.vikalp.dao.BlogsDao;
import com.vikalp.dao.UserDao;
import com.vikalp.model.AddBlogForm;
import com.vikalp.model.AddCommentForm;
import com.vikalp.model.Blog;
import com.vikalp.model.Comment;
import com.vikalp.model.CommentReplies;
import com.vikalp.model.Reply;
import com.vikalp.model.User;

@Controller
public class BlogsController {

	@Autowired
	@Qualifier("blogsDao")
	private BlogsDao blogsDao;
	
	@Autowired
	private UserDao userDao;

	final static Logger logger = Logger.getLogger(BlogsController.class);

	@RequestMapping(value = "getBlogs.htm")
	public ModelAndView getBlogs(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		model.addAttribute("blogs", blogsDao.getAllBlogs());
		return new ModelAndView("blog");
	}

	@RequestMapping(value = "blogdetails.htm", method = RequestMethod.GET)
	public ModelAndView getBlogDetails(Model model, HttpServletRequest request,
			HttpSession session, HttpServletResponse response,
			@ModelAttribute("addCommentForm") AddCommentForm addCommentForm) {

		String msg = "success";
		try {
			Blog blog = blogsDao.getBlogDetails(Integer.parseInt(request
					.getParameter("id").toString()));
			  blog.setDetails(StringEscapeUtils.unescapeHtml(blog.getDetails()));
			model.addAttribute("blog", blog);

			boolean isLiked = false;
			Integer userId=0;

			if (session.getAttribute("uname") != null) {
				userId = (userDao.userDetail(session.getAttribute("uname").toString())).getId();
				isLiked = blogsDao
						.isLikedAlready(Integer.parseInt(request.getParameter(
								"id").toString()), userId );
			}

			model.addAttribute("isLiked", isLiked);

			List<Comment> coms = blogsDao.getBlogComments(Integer
					.parseInt(request.getParameter("id").toString()),userId);

			List<CommentReplies> CR = new ArrayList<CommentReplies>();
			List<Reply> replies = new ArrayList<Reply>();
			Integer comId = 0;
			CommentReplies rep = null;
			for (int i = 0; i < coms.size(); i++) {

				Comment c = coms.get(i);

				if (i == 0) {
					comId = c.getCommentId();
					rep = new CommentReplies(c.getCommentId(), c.getComment(),
							c.getCommentBy(), c.getCommentedOn(),
							c.getCommenterId(), c.getCommentPic(),
							c.getCommentVideo(),c.getCommentLikes(),c.getCommentFlag());
					// if(c.getRepliedBy()!=null){
					// Reply s = new
					// Reply(c.getReplyDetails(),c.getRepliedBy(),c.getRepliedOn());
					// replies.add(s);
					// }

				}

				if (comId != c.getCommentId()) {

					rep.setReplies(replies);
					CR.add(rep);
					rep = new CommentReplies(c.getCommentId(), c.getComment(),
							c.getCommentBy(), c.getCommentedOn(),
							c.getCommenterId(), c.getCommentPic(),
							c.getCommentVideo(),c.getCommentLikes(),c.getCommentFlag());
					replies = new ArrayList<Reply>();
					if (c.getRepliedBy() != null) {
						Reply s = new Reply(c.getReplyId(),c.getReplyDetails(),
								c.getRepliedBy(), c.getRepliedOn(),
								c.getReplierId(),c.getReplyLikes(),c.getReplyFlag());
						replies.add(s);
					}
					comId = c.getCommentId();
				} else {
					if (c.getRepliedBy() != null) {
						Reply s = new Reply(c.getReplyId(),c.getReplyDetails(),
								c.getRepliedBy(), c.getRepliedOn(),
								c.getReplierId(),c.getReplyLikes(),c.getReplyFlag());
						replies.add(s);
					}
				}

			}
			if (rep != null) {
				rep.setReplies(replies);
				CR.add(rep);
			}

			model.addAttribute("comments", CR);

		}catch (Exception e) {
			msg="fail to fetch detail";
		}
		model.addAttribute("msg", msg);
		return new ModelAndView("post");
	}

//	@RequestMapping(value = "getComments.htm")
//	public ModelAndView getComments(Model model, HttpServletRequest request,
//			HttpServletResponse response) {
//		blogsDao.getBlogComments(1);
//		return new ModelAndView("post");
//	}

	@RequestMapping(value = "writeblog.htm", method = RequestMethod.GET)
	public ModelAndView WriteBlog(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("addBlogForm") AddBlogForm addBlogForm) {
		return new ModelAndView("write");
	}

	@RequestMapping(value = "writeblog.htm", method = RequestMethod.POST)
	public String WriteBlogData(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("addBlogForm") AddBlogForm addBlogForm) {

		String msg = "Blog Added Successfully.";
		try{
		String user = request.getSession().getAttribute("uname").toString();
		addBlogForm.setCreatedBy(user);
		addBlogForm.setBlogText(StringEscapeUtils.escapeHtml(addBlogForm.getBlogText()));
		boolean res = blogsDao.addBlog(addBlogForm);
		if(!res){
			msg="fail to add blog";
		}
	}catch (Exception e) {
		msg="fail to add blog";
	}
	model.addAttribute("msg", msg);
		return "redirect:/getBlogs.htm";
	}

	@RequestMapping(value = "blogdetails.htm", method = RequestMethod.POST)
	public String addComment(Model model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("addCommentForm") AddCommentForm addCommentForm) {
		String msg = "success";
		String blogId = null;
		try{
		blogId = request.getParameter("blogId").toString();
		addCommentForm.setComment(StringEscapeUtils.escapeHtml(addCommentForm.getComment()));
		
		Object us = request.getSession().getAttribute("uname");
		if (us != null) {
			addCommentForm.setCreatedBy(us.toString());
		}

		blogsDao.addComment(addCommentForm, Integer.parseInt(blogId));
	}catch (Exception e) {
		msg="fail to fetch detail";
	}
	model.addAttribute("msg", msg);

		return "redirect:/blogdetails.htm?id=" + blogId;
	}

	/*
	 * @RequestMapping(value = "AddComment.htm") public String addComment(Model
	 * model, HttpServletRequest request, HttpServletResponse response) { String
	 * blogId = request.getParameter("blogId").toString(); String comment =
	 * request.getParameter("comment").toString(); String user =
	 * request.getSession().getAttribute("uname").toString();
	 * blogsDao.addComment(Integer.parseInt(blogId), comment, user);
	 * 
	 * return "redirect:/blogdetails.htm?id="+blogId; }
	 */

	@RequestMapping(value = "updatelikes.htm", method = RequestMethod.GET)
	public @ResponseBody
	String updatelikes(HttpSession session, @RequestParam int blogId)
			throws Exception {
		String result = null;
		try {
			
			User user = userDao.userDetail(session.getAttribute("uname").toString());
			result = blogsDao.updateLikes(user, blogId);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		return result;
	}

	@RequestMapping(value = "updatecommentlikes.htm", method = RequestMethod.GET)
	public @ResponseBody
	String updateCommentlikes(HttpSession session, @RequestParam int commentId)
			throws Exception {
		String result = null;
		try {
			result = blogsDao.updateCommentLikes(userDao.userDetail(session.getAttribute("uname").toString()), commentId);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}
	
	@RequestMapping(value = "updatereplylikes.htm", method = RequestMethod.GET)
	public @ResponseBody
	String updateReplylikes(HttpSession session, @RequestParam int replyId)
			throws Exception {
		String result = null;
		try {
			result = blogsDao.updateReplyLikes(userDao.userDetail(session.getAttribute("uname").toString()), replyId);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}
	
	@RequestMapping(value = "deActiveBlog.htm", method = RequestMethod.GET)
	public @ResponseBody
	String deActiveBlog(HttpSession session, @RequestParam int blogId)
			throws Exception {
		String result = null;
		try {
			result = blogsDao.deActiveBlog(blogId);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "AddReply.htm")
	public String AddReply(Model model, HttpServletRequest request,
			HttpServletResponse response) {
		String msg = "success";
		String blogId = "";
		try{
		String commentId = request.getParameter("commentId").toString();
		blogId = request.getParameter("blogId").toString();
		String replyText = request.getParameter("replyText").toString();
		String user = request.getSession().getAttribute("uname").toString();
		blogsDao.addReply(Integer.parseInt(commentId), replyText, user);
	}catch (Exception e) {
		msg="fail to fetch detail";
	}
	model.addAttribute("msg", msg);
		return "redirect:/blogdetails.htm?id=" + blogId;
	}
}