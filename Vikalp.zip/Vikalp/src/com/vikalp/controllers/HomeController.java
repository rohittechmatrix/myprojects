package com.vikalp.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vikalp.dao.BlogsDao;
import com.vikalp.dao.CausesDao;
import com.vikalp.dao.UserDao;
import com.vikalp.model.Cause;
import com.vikalp.model.NGODetail;

@Controller
public class HomeController {

	@Autowired
	@Qualifier("blogsDao")
	private BlogsDao blogsDao;

	@Autowired
	private UserDao userDao;

	@Autowired
	@Qualifier("causesDao")
	private CausesDao causesDao;

	final static Logger logger = Logger.getLogger(HomeController.class);

	@RequestMapping(value = "home.htm")
	public ModelAndView gotohome(Model model, HttpServletRequest request,
			HttpServletResponse response) {

		model.addAttribute("blogs", blogsDao.getBlogs());
		List<NGODetail> ngoDetail = userDao.getNgos();
		model.addAttribute("ngos", ngoDetail);
		List<Cause> topCauses = causesDao.getCauses("", "");
		if (topCauses.size() > 6) {
			model.addAttribute("causes", topCauses.subList(0, 5));
		} else {
			model.addAttribute("causes", topCauses);
		}
		return new ModelAndView("home");
	}

}
