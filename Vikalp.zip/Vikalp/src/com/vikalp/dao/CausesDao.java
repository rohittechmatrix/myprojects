package com.vikalp.dao;

import java.util.List;

import com.vikalp.model.AddCauseForm;
import com.vikalp.model.Cause;
import com.vikalp.model.Support;

public interface CausesDao {

	public boolean deleteCause(int id, Object isCompleted);
	public List<Cause> getCauses(String userrole, String username);
	public List<Cause> getCausesByDeleteFlag(String userrole, String username);
	public List<Cause> getCausesByDeleteWithdrawn(String userrole, String username);
	public Cause getCauseDetail(int causeId);
	public Cause getCauseDetailComplete(int causeId);
	public boolean addCause(AddCauseForm addCauseForm, String user);
	public List<Cause> getCausesbyId(int parseInt);
	public boolean supportCause(int causeId, Integer userId, Object date , String pickaddress, String duration, String quantity);
	public String updateLikes(Object attribute, int causeId);
	public boolean isLikedAlready(int causeId, Integer id);
	public boolean setPriority(int causeId, int priority);
	List<Cause> getAllCauses(String userrole, String username);
	public List<Cause> getSupportedCauses();
	public List<Support> getSupportedCausesbyId(int parseInt);
	public List<Support> getSupporters(int parseInt);
	List<Support> getFulFilledSupportList();
}
