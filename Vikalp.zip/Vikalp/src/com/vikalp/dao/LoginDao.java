package com.vikalp.dao;

import com.vikalp.model.User;

public interface LoginDao {

	public String doLogout();
	public User doLogin(String uname, String pass);
	public boolean signUp(Object[] params, int[] types);
	public User getPassword(String usermail);
	public void updatePassword(String usrname, String oldPW, String newPW);
		
}
