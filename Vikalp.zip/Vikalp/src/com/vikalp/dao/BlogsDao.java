package com.vikalp.dao;

import java.util.List;

import com.vikalp.model.AddBlogForm;
import com.vikalp.model.AddCommentForm;
import com.vikalp.model.Comment;

import com.vikalp.model.Blog;

public interface BlogsDao {

	public List<Blog> getAllBlogs();
	public List<Blog> getAllBlogsByUser(String uname);
	public Blog getBlogDetails(int id);
	public List<Comment> getBlogComments(int id, Integer userId);
	public boolean addComment(AddCommentForm addCommentForm , int blogId);
	public boolean addBlog(AddBlogForm addBlogForm);
	public boolean addReply(int parseInt, String replyText, String user);
	public boolean isLikedAlready(int parseInt, Integer id);
	String updateLikes(Object obj, int blogId);
	public String deActiveBlog(int blogId);
	public boolean setPriority(int blogId, int priority);
	public List<Blog> getBlogs();
	public String updateCommentLikes(Object obj, int commentId);
	public String updateReplyLikes(Object obj, int replyId);
	
}
