package com.vikalp.dao;

public interface Deo {

	public boolean login(String us , String pas);
}
