package com.vikalp.dao;

import java.util.List;

import com.vikalp.model.NGO;
import com.vikalp.model.Support;

public interface AdminDao {

	public List<NGO> listNGOs();
	boolean activateNGO(int id, String action);
	public List<NGO> listDonators();
	public List<Support> getSupportList();
	public List<Support> getSupportListByUser(int id);
	public List<NGO> listActiveNGOs();
	public boolean deActivateDonor(int userid);
	public boolean deActivateCause(int causeid);
	public String getUserMail(String ngoname);
	public List<NGO> listRawDonators();
	public boolean activateDonor(int userid);
	public List<Support> getSupportListDonor(Integer id);
}
