package com.vikalp.dao;

import java.util.List;

import com.vikalp.model.DonorDetailForm;
import com.vikalp.model.NGODetail;
import com.vikalp.model.NGODetailForm;
import com.vikalp.model.User;

public interface UserDao {

	User userDetail(String username);

	boolean saveUserDetail(NGODetailForm ngoDetailForm);
	void saveDonorDetail(DonorDetailForm donorDetailForm, User user);

	NGODetail getNgo(Integer user);

	List<NGODetail> getNgos();

	NGODetailForm getNGODetailForm(String uname);
	boolean editNgoDescription(Integer id , String Description);
	String ngoDescription(Integer id);
}
