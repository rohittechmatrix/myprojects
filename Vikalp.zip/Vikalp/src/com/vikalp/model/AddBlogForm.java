package com.vikalp.model;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;


public class AddBlogForm {

	private String blog;
	private String blogText;
	private MultipartFile images;
	private String createdBy;
	private Date createdOn;
	private String imageUrl;
	private String video;
	
	public AddBlogForm() {
		super();
	}
	
	public AddBlogForm(String blog, String blogText, MultipartFile images,
			String createdBy, Date createdOn, String imageUrl, String video) {
		super();
		this.blog = blog;
		this.blogText = blogText;
		this.images = images;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.imageUrl = imageUrl;
		this.video = video;
	}

	public String getBlog() {
		return blog;
	}

	public void setBlog(String blog) {
		this.blog = blog;
	}

	public String getBlogText() {
		return blogText;
	}

	public void setBlogText(String blogText) {
		this.blogText = blogText;
	}

	public MultipartFile getImages() {
		return images;
	}

	public void setImages(MultipartFile images) {
		this.images = images;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}



	public String getImageUrl() {
		return imageUrl;
	}



	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}






	public String getVideo() {
		return video;
	}






	public void setVideo(String video) {
		this.video = video;
	}
	
	


	
}
