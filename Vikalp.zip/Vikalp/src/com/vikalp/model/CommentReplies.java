package com.vikalp.model;

import java.sql.Date;
import java.util.List;

public class CommentReplies {

	private Integer commentId;
	private String comment;
	private String commentBy;
	private Date commentedOn;
	private List<Reply> replies;
	private String commenterId;
	private String commentPic;
	private String commentVideo;
	private Integer commentLikes;
	private Integer commentFlag;
	public CommentReplies() {
		super();
	}






	public CommentReplies(Integer commentId, String comment, String commentBy,
			Date commentedOn, String commenterId,
			String commentPic, String commentVideo, Integer commentLikes,
			Integer commentFlag) {
		super();
		this.commentId = commentId;
		this.comment = comment;
		this.commentBy = commentBy;
		this.commentedOn = commentedOn;
		this.commenterId = commenterId;
		this.commentPic = commentPic;
		this.commentVideo = commentVideo;
		this.commentLikes = commentLikes;
		this.commentFlag = commentFlag;
	}






	public Integer getCommentId() {
		return commentId;
	}



	public void setCommentId(Integer commentId) {
		this.commentId = commentId;
	}



	public String getComment() {
		return comment;
	}



	public void setComment(String comment) {
		this.comment = comment;
	}



	public String getCommentBy() {
		return commentBy;
	}



	public void setCommentBy(String commentBy) {
		this.commentBy = commentBy;
	}



	public Date getCommentedOn() {
		return commentedOn;
	}



	public void setCommentedOn(Date commentedOn) {
		this.commentedOn = commentedOn;
	}



	public List<Reply> getReplies() {
		return replies;
	}



	public void setReplies(List<Reply> replies) {
		this.replies = replies;
	}



	public String getCommenterId() {
		return commenterId;
	}



	public void setCommenterId(String commenterId) {
		this.commenterId = commenterId;
	}





	public String getCommentPic() {
		return commentPic;
	}





	public void setCommentPic(String commentPic) {
		this.commentPic = commentPic;
	}








	public String getCommentVideo() {
		return commentVideo;
	}








	public void setCommentVideo(String commentVideo) {
		this.commentVideo = commentVideo;
	}













	public Integer getCommentLikes() {
		return commentLikes;
	}













	public void setCommentLikes(Integer commentLikes) {
		this.commentLikes = commentLikes;
	}








	public Integer getCommentFlag() {
		return commentFlag;
	}








	public void setCommentFlag(Integer commentFlag) {
		this.commentFlag = commentFlag;
	}




	
}
