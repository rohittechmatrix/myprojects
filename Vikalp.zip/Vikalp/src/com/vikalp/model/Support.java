package com.vikalp.model;

import java.sql.Date;

public class Support {

	private Integer causeId;
	private String ngoUsername;
	private String title;
	private String name;
	private String number;
	private Integer amount;
	private String supportedOn;
	private String address;

	
	public Support(){
		
	}


	


	public Support(Integer causeId, String ngoUsername, String title,
			String name, String number, Integer amount, String supportedOn,
			String address) {
		super();
		this.causeId = causeId;
		this.ngoUsername = ngoUsername;
		this.title = title;
		this.name = name;
		this.number = number;
		this.amount = amount;
		this.supportedOn = supportedOn;
		this.address = address;
	}





	public Integer getCauseId() {
		return causeId;
	}


	public void setCauseId(Integer causeId) {
		this.causeId = causeId;
	}


	public String getNgoUsername() {
		return ngoUsername;
	}


	public void setNgoUsername(String ngoUsername) {
		this.ngoUsername = ngoUsername;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getNumber() {
		return number;
	}


	public void setNumber(String number) {
		this.number = number;
	}


	public Integer getAmount() {
		return amount;
	}


	public void setAmount(Integer amount) {
		this.amount = amount;
	}


	public String getSupportedOn() {
		return supportedOn;
	}


	public void setSupportedOn(String supportedOn) {
		this.supportedOn = supportedOn;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
}
