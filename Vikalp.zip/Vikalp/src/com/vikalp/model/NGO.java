package com.vikalp.model;


public class NGO {

	private Integer id;
	private String name;
	private String email;
	private String number;
	private String userType;
	private String address;
	private String registrationNo;
	private String nationality;
	private String accountNo;
	private String bankName;
	private String username;
	private String ifscCode;
	private String fcra;
	private String section80g;
	private String contactPerson;
	
	
	
	public NGO() {
		super();
	}


	public NGO(Integer id, String name, String email, String number,
			String userType, String address, String registrationNo,
			String nationality, String accountNo, String bankName,
			String username, String ifscCode, String fcra, String section80g,
			String contactPerson) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.number = number;
		this.userType = userType;
		this.address = address;
		this.registrationNo = registrationNo;
		this.nationality = nationality;
		this.accountNo = accountNo;
		this.bankName = bankName;
		this.setUsername(username);
		this.ifscCode = ifscCode;
		this.fcra = fcra;
		this.section80g = section80g;
		this.contactPerson = contactPerson;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getFcra() {
		return fcra;
	}

	public void setFcra(String fcra) {
		this.fcra = fcra;
	}

	public String getSection80g() {
		return section80g;
	}

	public void setSection80g(String section80g) {
		this.section80g = section80g;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}
	
	
}
