package com.vikalp.model;


public class NGODetail {

	private Integer ngo_id;
	private String ngo_username;
	private String name;
	private String description;
	private String logo_url;
	private String causes_supported;
	private String web_url;
	private String ngo_picture;
	
	public NGODetail() {
		super();
	}

	public NGODetail(Integer ngo_id, String ngo_username, String name,
			String description, String logo_url, String causes_supported,
			String web_url, String ngo_picture) {
		super();
		this.ngo_id = ngo_id;
		this.ngo_username = ngo_username;
		this.name = name;
		this.description = description;
		this.logo_url = logo_url;
		this.causes_supported = causes_supported;
		this.web_url = web_url;
		this.ngo_picture = ngo_picture;
	}

	public Integer getNgo_id() {
		return ngo_id;
	}

	public void setNgo_id(Integer ngo_id) {
		this.ngo_id = ngo_id;
	}

	public String getNgo_username() {
		return ngo_username;
	}

	public void setNgo_username(String ngo_username) {
		this.ngo_username = ngo_username;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLogo_url() {
		return logo_url;
	}

	public void setLogo_url(String logo_url) {
		this.logo_url = logo_url;
	}

	public String getCauses_supported() {
		return causes_supported;
	}

	public void setCauses_supported(String causes_supported) {
		this.causes_supported = causes_supported;
	}

	public String getWeb_url() {
		return web_url;
	}

	public void setWeb_url(String web_url) {
		this.web_url = web_url;
	}

	public String getNgo_picture() {
		return ngo_picture;
	}

	public void setNgo_picture(String ngo_picture) {
		this.ngo_picture = ngo_picture;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
