package com.vikalp.model;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;


public class AddCommentForm {

	private String comment;
	private MultipartFile images;
	private String createdBy;
	private String videourl;
	private Integer blogId;
	private Date createdOn;
	
	
	public AddCommentForm() {
		super();
	}














	public AddCommentForm(String comment, MultipartFile images,
			String createdBy, String videourl, Integer blogId, Date createdOn) {
		super();
		this.comment = comment;
		this.images = images;
		this.createdBy = createdBy;
		this.videourl = videourl;
		this.blogId = blogId;
		this.createdOn = createdOn;
	}














	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	public MultipartFile getImages() {
		return images;
	}


	public void setImages(MultipartFile images) {
		this.images = images;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}




	public Date getCreatedOn() {
		return createdOn;
	}




	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}




	public Integer getBlogId() {
		return blogId;
	}




	public void setBlogId(Integer blogId) {
		this.blogId = blogId;
	}







	public String getVideourl() {
		return videourl;
	}







	public void setVideourl(String videourl) {
		this.videourl = videourl;
	}
	

	


	
}
