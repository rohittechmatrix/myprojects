package com.vikalp.model;

import java.sql.Date;

public class Blog {

	private Integer blogId;
	private String title;
	private String details;
	private String createdBy;
	private Date createdOn;
	private Integer likes;
	private Integer commentCount;
	private String imageUrl;
	private Integer priority;
	private String video;
	
	public Blog() {
		super();
	}
	
	public Blog(Integer blogId, String title, String details, String createdBy,
			Date createdOn, Integer likes, Integer commentCount,
			String imageUrl, Integer priority,String video) {
		super();
		this.blogId = blogId;
		this.title = title;
		this.details = details;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.likes = likes;
		this.commentCount = commentCount;
		this.imageUrl = imageUrl;
		this.priority = priority;
		this.video = video;
	}

	public Integer getLikes() {
		return likes;
	}

	public void setLikes(Integer likes) {
		this.likes = likes;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public Integer getBlogId() {
		return blogId;
	}

	public void setBlogId(Integer blogId) {
		this.blogId = blogId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(Integer commentCount) {
		this.commentCount = commentCount;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}




	public Integer getPriority() {
		return priority;
	}




	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getVideo() {
		return video;
	}

	public void setVideo(String video) {
		this.video = video;
	}
}
