package com.vikalp.model;

import org.springframework.web.multipart.MultipartFile;

public class DonorDetailForm {
	private MultipartFile images;
	private Integer id;
	
		
	public DonorDetailForm() {
		super();
	}

	public DonorDetailForm(MultipartFile images, Integer id, String[] oppType) {
		super();
		this.images = images;
		this.id = id;
		
	}

	public MultipartFile getImages() {
		return images;
	}

	public void setImages(MultipartFile images) {
		this.images = images;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


}
