package com.vikalp.model;

import java.util.Date;


import org.springframework.web.multipart.MultipartFile;


public class AddCauseForm {

	private String heading;
	private String type;
	private String amount;
	private String details;
	private MultipartFile images;
	private String user;
	private Date added;
	
	
	public AddCauseForm() {
		super();
	}

	public AddCauseForm(String heading, String type, String amount,
			String details, MultipartFile image, String user, Date added) {
		super();
		this.heading = heading;
		this.type = type;
		this.amount = amount;
		this.details = details;
		this.setImages(image);
		this.user = user;
		this.added = added;
	}

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	


	public String getUser() {
		return user;
	}



	public void setUser(String user) {
		this.user = user;
	}

	public Date getAdded() {
		return added;
	}

	public void setAdded(Date added) {
		this.added = added;
	}

	public MultipartFile getImages() {
		return images;
	}

	public void setImages(MultipartFile images) {
		this.images = images;
	}
}
