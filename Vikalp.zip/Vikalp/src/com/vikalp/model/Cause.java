package com.vikalp.model;

import java.sql.Date;

public class Cause {

	private Integer causeId;
	private String type;
	private String title;
	private String details;
	private String image;
	private String amount;
	private String ngoUsername;
	private Date addedOn;
	private String address;
	private Integer deleteFlag;
	private Date deletedOn;
	private Integer isCompleted;
	private String bankName;
	private String iisfsc;
	private String accountNumber;
	public Cause(){
		
	}
			
	

	


	public Cause(Integer causeId, String type, String title, String details,
			String image, String amount, String ngoUsername, Date addedOn,
			String address, Integer deleteFlag, Date deletedOn,
			Integer isCompleted, String bankName, String iisfsc,
			String accountNumber) {
		super();
		this.causeId = causeId;
		this.type = type;
		this.title = title;
		this.details = details;
		this.image = image;
		this.amount = amount;
		this.ngoUsername = ngoUsername;
		this.addedOn = addedOn;
		this.address = address;
		this.deleteFlag = deleteFlag;
		this.deletedOn = deletedOn;
		this.isCompleted = isCompleted;
		this.bankName = bankName;
		this.iisfsc = iisfsc;
		this.accountNumber = accountNumber;
	}






	public Integer getCauseId() {
		return causeId;
	}

	public void setCauseId(Integer causeId) {
		this.causeId = causeId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getNgoUsername() {
		return ngoUsername;
	}

	public void setNgoUsername(String ngoUsername) {
		this.ngoUsername = ngoUsername;
	}
	
	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}



	
	public Integer getIsCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(Integer isCompleted) {
		this.isCompleted = isCompleted;
	}

	public Integer getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(Integer deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public Date getDeletedOn() {
		return deletedOn;
	}

	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}



	public String getAccountNumber() {
		return accountNumber;
	}



	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}



	public String getIisfsc() {
		return iisfsc;
	}



	public void setIisfsc(String iisfsc) {
		this.iisfsc = iisfsc;
	}



	public String getBankName() {
		return bankName;
	}



	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
}
