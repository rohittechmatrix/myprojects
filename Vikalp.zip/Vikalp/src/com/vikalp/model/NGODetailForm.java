package com.vikalp.model;

import org.springframework.web.multipart.MultipartFile;

public class NGODetailForm {

	private String name;
	private String phonesignup;
	private String addresssignup;
	private String emailsignup;
	private String usernamesignup;
	private String passwordsignup;
	private String nationality;
	private String regnumber;
	private String acnumber;
	private String ifscnumber;
	private String bank;
	private String fcra;
	private String section80g;
	private String contact_person;
	private String registration_date;
	private String expiry_date;
	private String userType;
	private Integer activeFlag;
	
	
	private MultipartFile[] images;
	private String ngoname;
	private String description;
	private String[] oppType;
	private MultipartFile certificate;
	
	public NGODetailForm() {
		super();
	}

	


	







	public NGODetailForm(String name, String phonesignup, String addresssignup,
			String emailsignup, String usernamesignup, String passwordsignup,
			String nationality, String regnumber, String acnumber,
			String ifscnumber, String bank, String fcra, String section80g,
			String contact_person, String registration_date,
			String expiry_date, String userType, Integer activeFlag,
			MultipartFile[] images, String ngoname, String description,
			String[] oppType, MultipartFile certificate) {
		super();
		this.name = name;
		this.phonesignup = phonesignup;
		this.addresssignup = addresssignup;
		this.emailsignup = emailsignup;
		this.usernamesignup = usernamesignup;
		this.passwordsignup = passwordsignup;
		this.nationality = nationality;
		this.regnumber = regnumber;
		this.acnumber = acnumber;
		this.ifscnumber = ifscnumber;
		this.bank = bank;
		this.fcra = fcra;
		this.section80g = section80g;
		this.contact_person = contact_person;
		this.registration_date = registration_date;
		this.expiry_date = expiry_date;
		this.userType = userType;
		this.activeFlag = activeFlag;
		this.images = images;
		this.ngoname = ngoname;
		this.description = description;
		this.oppType = oppType;
		this.certificate = certificate;
	}












	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhonesignup() {
		return phonesignup;
	}

	public void setPhonesignup(String phonesignup) {
		this.phonesignup = phonesignup;
	}

	public String getAddresssignup() {
		return addresssignup;
	}

	public void setAddresssignup(String addresssignup) {
		this.addresssignup = addresssignup;
	}

	public String getUsernamesignup() {
		return usernamesignup;
	}

	public void setUsernamesignup(String usernamesignup) {
		this.usernamesignup = usernamesignup;
	}

	public String getPasswordsignup() {
		return passwordsignup;
	}

	public void setPasswordsignup(String passwordsignup) {
		this.passwordsignup = passwordsignup;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getRegnumber() {
		return regnumber;
	}

	public void setRegnumber(String regnumber) {
		this.regnumber = regnumber;
	}

	public String getAcnumber() {
		return acnumber;
	}

	public void setAcnumber(String acnumber) {
		this.acnumber = acnumber;
	}

	public String getIfscnumber() {
		return ifscnumber;
	}

	public void setIfscnumber(String ifscnumber) {
		this.ifscnumber = ifscnumber;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getFcra() {
		return fcra;
	}

	public void setFcra(String fcra) {
		this.fcra = fcra;
	}

	public String getSection80g() {
		return section80g;
	}

	public void setSection80g(String section80g) {
		this.section80g = section80g;
	}

	public String getContact_person() {
		return contact_person;
	}

	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}

	public String getRegistration_date() {
		return registration_date;
	}

	public void setRegistration_date(String registration_date) {
		this.registration_date = registration_date;
	}

	public String getExpiry_date() {
		return expiry_date;
	}

	public void setExpiry_date(String expiry_date) {
		this.expiry_date = expiry_date;
	}

	public MultipartFile[] getImages() {
		return images;
	}

	public void setImages(MultipartFile[] images) {
		this.images = images;
	}

	public String getNgoname() {
		return ngoname;
	}

	public void setNgoname(String ngoname) {
		this.ngoname = ngoname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String[] getOppType() {
		return oppType;
	}

	public void setOppType(String[] oppType) {
		this.oppType = oppType;
	}

	public MultipartFile getCertificate() {
		return certificate;
	}

	public void setCertificate(MultipartFile certificate) {
		this.certificate = certificate;
	}

	public String getEmailsignup() {
		return emailsignup;
	}

	public void setEmailsignup(String emailsignup) {
		this.emailsignup = emailsignup;
	}







	public String getUserType() {
		return userType;
	}







	public void setUserType(String userType) {
		this.userType = userType;
	}







	public Integer getActiveFlag() {
		return activeFlag;
	}







	public void setActiveFlag(Integer activeFlag) {
		this.activeFlag = activeFlag;
	}
}
