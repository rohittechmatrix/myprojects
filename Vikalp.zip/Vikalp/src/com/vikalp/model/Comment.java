package com.vikalp.model;

import java.sql.Date;

public class Comment {

	private Integer commentId;
	private String comment;
	private String commentBy;
	private Date commentedOn;
	private String replyDetails;
	private String repliedBy;
	private Date repliedOn;
	private String commenterId;
	private String replierId;
	private String commentPic;
	private String commentVideo;
	private Integer replyId;
	private Integer commentLikes;
	private Integer replyLikes;
	private Integer commentFlag;
	private Integer replyFlag;

	public Comment() {
		super();
	}

	





	public Comment(Integer commentId, String comment, String commentBy,
			Date commentedOn, String replyDetails, String repliedBy,
			Date repliedOn, String commenterId, String replierId,
			String commentPic, String commentVideo, Integer replyId,
			Integer commentLikes, Integer replyLikes, Integer commentFlag,
			Integer replyFlag) {
		super();
		this.commentId = commentId;
		this.comment = comment;
		this.commentBy = commentBy;
		this.commentedOn = commentedOn;
		this.replyDetails = replyDetails;
		this.repliedBy = repliedBy;
		this.repliedOn = repliedOn;
		this.commenterId = commenterId;
		this.replierId = replierId;
		this.commentPic = commentPic;
		this.commentVideo = commentVideo;
		this.replyId = replyId;
		this.commentLikes = commentLikes;
		this.replyLikes = replyLikes;
		this.commentFlag = commentFlag;
		this.replyFlag = replyFlag;
	}







	public Integer getCommentId() {
		return commentId;
	}

	public void setCommentId(Integer commentId) {
		this.commentId = commentId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getCommentBy() {
		return commentBy;
	}

	public void setCommentBy(String commentBy) {
		this.commentBy = commentBy;
	}

	public Date getCommentedOn() {
		return commentedOn;
	}

	public void setCommentedOn(Date commentedOn) {
		this.commentedOn = commentedOn;
	}



	public String getReplyDetails() {
		return replyDetails;
	}



	public void setReplyDetails(String replyDetails) {
		this.replyDetails = replyDetails;
	}



	public String getRepliedBy() {
		return repliedBy;
	}



	public void setRepliedBy(String repliedBy) {
		this.repliedBy = repliedBy;
	}



	public Date getRepliedOn() {
		return repliedOn;
	}



	public void setRepliedOn(Date repliedOn) {
		this.repliedOn = repliedOn;
	}



	public String getReplierId() {
		return replierId;
	}



	public void setReplierId(String replierId) {
		this.replierId = replierId;
	}



	public String getCommenterId() {
		return commenterId;
	}



	public void setCommenterId(String commenterId) {
		this.commenterId = commenterId;
	}





	public String getCommentPic() {
		return commentPic;
	}





	public void setCommentPic(String commentPic) {
		this.commentPic = commentPic;
	}










	public String getCommentVideo() {
		return commentVideo;
	}










	public void setCommentVideo(String commentVideo) {
		this.commentVideo = commentVideo;
	}



















	public Integer getReplyId() {
		return replyId;
	}



















	public void setReplyId(Integer replyId) {
		this.replyId = replyId;
	}






































	public Integer getCommentLikes() {
		return commentLikes;
	}






































	public void setCommentLikes(Integer commentLikes) {
		this.commentLikes = commentLikes;
	}






































	public Integer getReplyLikes() {
		return replyLikes;
	}






































	public void setReplyLikes(Integer replyLikes) {
		this.replyLikes = replyLikes;
	}





























































	public Integer getCommentFlag() {
		return commentFlag;
	}





























































	public void setCommentFlag(Integer commentFlag) {
		this.commentFlag = commentFlag;
	}





























































	public Integer getReplyFlag() {
		return replyFlag;
	}





























































	public void setReplyFlag(Integer replyFlag) {
		this.replyFlag = replyFlag;
	}
}
