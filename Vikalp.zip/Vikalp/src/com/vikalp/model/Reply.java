package com.vikalp.model;

import java.sql.Date;

public class Reply {

	private Integer replyId;
	private String replyDetails;
	private String repliedBy;
	private Date repliedOn;
	private String replierId;
	private Integer replyLikes;
	private Integer replyFlag;
	public Reply() {
		super();
	}






	public Reply(Integer replyId, String replyDetails, String repliedBy,
			Date repliedOn, String replierId, Integer replyLikes,
			Integer replyFlag) {
		super();
		this.replyId = replyId;
		this.replyDetails = replyDetails;
		this.repliedBy = repliedBy;
		this.repliedOn = repliedOn;
		this.replierId = replierId;
		this.replyLikes = replyLikes;
		this.replyFlag = replyFlag;
	}






	public String getReplyDetails() {
		return replyDetails;
	}


	public void setReplyDetails(String replyDetails) {
		this.replyDetails = replyDetails;
	}


	public String getRepliedBy() {
		return repliedBy;
	}


	public void setRepliedBy(String repliedBy) {
		this.repliedBy = repliedBy;
	}


	public Date getRepliedOn() {
		return repliedOn;
	}


	public void setRepliedOn(Date repliedOn) {
		this.repliedOn = repliedOn;
	}


	public String getReplierId() {
		return replierId;
	}


	public void setReplierId(String replierId) {
		this.replierId = replierId;
	}




	public Integer getReplyId() {
		return replyId;
	}




	public void setReplyId(Integer replyId) {
		this.replyId = replyId;
	}









	public Integer getReplyLikes() {
		return replyLikes;
	}









	public void setReplyLikes(Integer replyLikes) {
		this.replyLikes = replyLikes;
	}












	public Integer getReplyFlag() {
		return replyFlag;
	}












	public void setReplyFlag(Integer replyFlag) {
		this.replyFlag = replyFlag;
	}

	
	


}
