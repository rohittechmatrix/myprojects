var passionTrails = angular.module("trailsApp", []).config(function($sceProvider) {
    // Completely disable SCE. For demonstration purposes only!
    // Do not use in new projects.
    // for IE 7
    $sceProvider.enabled(false);
});



passionTrails.controller('trailsController', function($scope , $http) {

	 $scope.app='';
    
    $scope.app='wanderlast';

	$scope.trailsList=[{
		id:"2",
		title:"",
		  formUrl:''
	}]



// $http.get('Cache/manali.html').
//   success(function(data, status, headers, config) {
// $('.fancybox-type-iframe .fancybox-inner').html('').html(data);
//   }).
//   error(function(data, status, headers, config) {
//     // called asynchronously if an error occurs
//     // or server returns response with an error status.
//   });

$scope.openFrame= function(url , title , cls){

$('body').removeClass('frame');
	$('body').addClass(cls);
  $scope.currentTrails = title;

$('.modal-body').html('').html(' <iframe src="'+url+'" height="100%" width="100%" ></iframe>');
}
});